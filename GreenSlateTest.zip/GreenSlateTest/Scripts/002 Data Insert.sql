truncate table [dbo].[Users]
truncate table [dbo].[Projects]
truncate table [dbo].[UserProjects]

INSERT INTO [dbo].[Users]
           ([FirstName],[LastName])
     VALUES
           ('Marlon','Dailey'),('Linford','Dailey'),('Alex','Ujueta')

INSERT INTO [dbo].[Projects]
           ([StartDate],[EndDate],[Credits])
	VALUES 
			(dateadd(day,-cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,dateadd(day,cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,cast(  ((RAND() * 365) + 1) as int )),
			(dateadd(day,-cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,dateadd(day,cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,cast(  ((RAND() * 365) + 1) as int )),
			(dateadd(day,-cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,dateadd(day,cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,cast(  ((RAND() * 365) + 1) as int )),
			(dateadd(day,-cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,dateadd(day,cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,cast(  ((RAND() * 365) + 1) as int )),
			(dateadd(day,-cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,dateadd(day,cast(  ((RAND() * 365) + 1) as int ),GETDATE()) ,cast(  ((RAND() * 365) + 1) as int ))
			
INSERT INTO [dbo].[UserProjects]
           ([UserId],[ProjectId],[IsActive],[AssignedDate])

select a.Id,b.Id,cast(  (b.Id % 2) as int ),DATEADD(day,-1,b.StartDate)  from 
	dbo.Users a, dbo.Projects  b