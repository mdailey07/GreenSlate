﻿CREATE TABLE [dbo].UserProject
(
	[Id] INT NOT NULL PRIMARY KEY identity(1,1),
	[Userid] int not null , 
	ProjectId int not null , 
	IsActive BIT not null, 
    [AssignedDate] DATETIME NULL, 
)
