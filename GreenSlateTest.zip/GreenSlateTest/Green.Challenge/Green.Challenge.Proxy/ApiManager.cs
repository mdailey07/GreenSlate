﻿using Green.Challenge.Proxy.Common;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Green.Challenge.Proxy
{
    public class ApiManager : IApiManager
    {
        private const string AppJson = "application/json";

        public async Task<ResponseGeneric<T>> Call<T>(T model, string connectionApiName, string controllerMethod, ApiConnectionsElement xApiConnectionsElement = null)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var json = model.GetType().IsArray ? (model as Array).SerializeToJson() : model.SerializeToJson();

                    var content = new StringContent(json, Encoding.UTF8, AppJson);

                    var appiConnections = new ApiConnectionsElement();
                    appiConnections = xApiConnectionsElement ?? ApiConnectionSection.CurrentConfigurationSection.Connections
                           .OfType<ApiConnectionsElement>().FirstOrDefault(a => a.Name.Trim().ToLower()
                               .Equals(connectionApiName.Trim()));

                    using (var response = await client.PostAsync($"{appiConnections.UrlPath}/{controllerMethod}", content))
                    {
                        if (!response.IsSuccessStatusCode) throw new Exception(response.RequestMessage.ToString());

                        var jsonResult = await response.Content.ReadAsStringAsync();

                        return jsonResult.DeSerializeFromJson<ResponseGeneric<T>>();
                    }
                }
            }
            catch (Exception e)
            {
                return new ResponseGeneric<T>(e);
            }
        }
        public async Task<ResponseGeneric<T>> Call<T>(object model, string connectionApiName, string controllerMethod, ApiConnectionsElement xApiConnectionsElement = null)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var content = new StringContent(model.SerializeToJson(), Encoding.UTF8, AppJson);

                    var appiConnections = new ApiConnectionsElement();
                    appiConnections = xApiConnectionsElement ?? ApiConnectionSection.CurrentConfigurationSection.Connections
                           .OfType<ApiConnectionsElement>().FirstOrDefault(a => a.Name.Trim().ToLower()
                               .Equals(connectionApiName.Trim()));

                    using (var response = await client.PostAsync($"{appiConnections.UrlPath}/{controllerMethod}", content))
                    {
                        if (!response.IsSuccessStatusCode) throw new Exception(response.RequestMessage.ToString());

                        var jsonResult = await response.Content.ReadAsStringAsync();

                        return jsonResult.DeSerializeFromJson<ResponseGeneric<T>>();
                    }
                }
            }
            catch (Exception e)
            {
                return new ResponseGeneric<T>(e);
            }
        }
    }
}
