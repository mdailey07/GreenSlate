﻿using System.Threading.Tasks;
using Green.Challenge.Proxy.Common;

namespace Green.Challenge.Proxy
{
    public interface IApiManager
    {
        Task<ResponseGeneric<T>> Call<T>(object model, string connectionApiName, string controllerMethod, ApiConnectionsElement xApiConnectionsElement = null);
        Task<ResponseGeneric<T>> Call<T>(T model, string connectionApiName, string controllerMethod, ApiConnectionsElement xApiConnectionsElement = null);
    }
}