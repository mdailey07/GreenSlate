﻿using Microsoft.Extensions.DependencyInjection;

namespace Green.Challenge.FrontEnd.Configuration
{
    public static class LibraryMap
    {
        public static void AutoOwnerLibraryMap(this IServiceCollection service)
        {
            service.AddTransient<Proxy.Common.IResponse, Proxy.Common.Response>();
            service.AddTransient<Proxy.IApiManager, Proxy.ApiManager>();

            service.AddTransient<Common.IUser, Common.User>();
            service.AddTransient<Common.IUserProject, Common.UserProject>();
            service.AddTransient<Common.IProject, Common.Project>();


        }
    }
}
