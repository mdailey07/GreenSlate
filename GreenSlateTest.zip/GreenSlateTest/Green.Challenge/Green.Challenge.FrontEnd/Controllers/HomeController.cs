﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Green.Challenge.FrontEnd.Models;
using Microsoft.Extensions.Configuration;
using Green.Challenge.Proxy;
using System.Collections.Generic;
using Green.Challenge.Common;
using System.Threading.Tasks;

namespace Green.Challenge.FrontEnd.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IApiManager _apiManager;
        private IUser _user;
        private IUserProject _userProject;
        
        public HomeController(IConfiguration configuration,IApiManager apiManager, IUser user, IUserProject userProject)
        {
            _configuration = configuration;
            _apiManager = apiManager;
            _user = user;
            _userProject = userProject;
        }

        //[VirtualDom]
        public IActionResult Index()
        {
            return View();
        }
        
        public async Task<JsonResult> loadUserAsync()
        {
            _user.FirstName  = _user.LastName = string.Empty;
            var resultUser = await _apiManager.Call<IEnumerable<User>>(_user, null, "Challenge/ListUser", new Proxy.Common.ApiConnectionsElement() { UrlPath = _configuration.GetSection("ApiConnection:Url").Value });
            return Json(resultUser);
        }
        
        public async Task<JsonResult> getProyectsAsync(UserProject user)
        {
            var resultUser = await _apiManager.Call<IEnumerable<UserProject>>(user, null, "Challenge/ListUserProjects", new Proxy.Common.ApiConnectionsElement() { UrlPath = _configuration.GetSection("ApiConnection:Url").Value });
            return Json(resultUser);
        }

        [VirtualDom]
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        [VirtualDom]
        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }
        [VirtualDom]
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
