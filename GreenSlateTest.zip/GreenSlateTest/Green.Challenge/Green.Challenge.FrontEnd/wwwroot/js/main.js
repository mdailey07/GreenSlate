﻿var mainFunctions = function () {

    let $selectUser = $("#SelectUser");
    let $table = $("#tbInformation");

    $(function () {
        fnInit();
    });

    var fnInit = function () {
        $selectUser.change(fnChange); 
        $selectUser.html("");
        fnCallBackEnd("Home/loadUserAsync", {}, fnLoadUser, fnError);
    };

    var fnChange = function () {
        let userid = (this).value;

        fnDestroyTable();

        if (userid != "0") 
            fnCallBackEnd("Home/getProyectsAsync", { UserId: userid }, fnloadtProjects, fnError);
    };

    var fnDestroyTable = function () {
        if ($.fn.DataTable.isDataTable("#tbInformation")) {
            let tbInformation = $("#tbInformation").DataTable();
            tbInformation.destroy();
            tbInformation.clear().draw();
        }
    }

    var fnloadtProjects = function (data) {
        if (data.status == 0) {
            let html = "";
            let options = {
                pagingType: "full_numbers",
                responsive: true,
                autoWidth: false,
                columns: [
                    { title: "Project id", data: "projectId" },
                    { title: "Start Date", data: "startDate" },
                    { title: "Time To Star", data: "timeToStart" },
                    { title: "End Date", data: "endDate" },
                    { title: "Credits", data: "credits" },
                    { title: "Status", data: "status" },
                ],
                pageLength: 10,
                searching: true,
                ordering: true,
                scrolX: true,
                data: data.response
            };

            $table.DataTable(options);
        }
        else {
            alert("Error");
        }
    };

    var fnError = function () {
        alert("Error in backend")
    };

    var fnLoadUser = function (data) {
        if (data.status == 0)  {
            let html = "";
            html += "<option value=0>--</option>";
            $.each(data.response, function (index, item) {
                html += "<option value=" + item.id +">" + item.fullName + "</option>";
            });
            $selectUser.html(html);
        }
        else {
            alert("Error");
        }
    };

    var fnCallBackEnd = function (url, data, fnSuccess,fnError) {
        $.ajax({
            url: url,
            type: "POST",
            data: data,
            async: true,
            dataType: "json",
            success: (data,textStatus,jqXHR) => {
                fnSuccess(data);
            },
            error:  (request,status,error) => {
                fnError(error);
            }
        });
    }

    return {
        ChangeSelect: fnChange,
        CallBackEnd: fnCallBackEnd,
    }

}();