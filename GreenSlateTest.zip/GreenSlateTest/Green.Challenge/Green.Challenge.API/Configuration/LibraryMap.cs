﻿using Microsoft.Extensions.DependencyInjection;

namespace Green.Challenge.API.Configuration
{
    public static class LibraryMap
    {
        public static void AutoOwnerLibraryMap(this IServiceCollection service)
        {
            service.AddTransient<Proxy.Common.IResponse, Proxy.Common.Response>();
            service.AddTransient<Proxy.IApiManager, Proxy.ApiManager>();

            service.AddTransient<Business.IDataAccessHelper, Business.DataAccessHelper>();
            service.AddTransient < DataAccess.IEFCoreDBContext, DataAccess.EFCoreDBContext>();
            
            service.AddTransient<Common.IUser, Common.User>();
            service.AddTransient<Common.IUserProject, Common.UserProject>();
            service.AddTransient<Common.IProject, Common.Project>();

            
        }
    }
}
