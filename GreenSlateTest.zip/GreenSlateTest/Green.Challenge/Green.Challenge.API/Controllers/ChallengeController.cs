﻿using System;
using System.Collections.Generic;
using Green.Challenge.Common;
using Green.Challenge.Proxy.Common;
using Microsoft.AspNetCore.Mvc;

namespace Green.Challenge.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChallengeController : ControllerBase
    {

        private readonly Business.IDataAccessHelper _DataAccessHelper;

        public ChallengeController (Business.IDataAccessHelper dataAccessHelper)
        {
            _DataAccessHelper = dataAccessHelper;
        }


        [HttpPost("ListUserProjects")]
        public ResponseGeneric<IEnumerable<UserProject>> ListUserProjects(UserProject model)
        {
            try
            {
                var result = _DataAccessHelper.FetchUserProjects(model);
                return new ResponseGeneric<IEnumerable<UserProject>>(result);
            }
            catch (Exception e)
            {
                return new ResponseGeneric<IEnumerable<UserProject>>(e);
            }
        }

        [HttpPost("ListUser")]
        public ResponseGeneric<IEnumerable<User>> ListUser(User model)
        {
            try
            {
                var result = _DataAccessHelper.FetchUsers();
                return new ResponseGeneric<IEnumerable<User>>(result);
            }
            catch (Exception e)
            {
                return new ResponseGeneric<IEnumerable<User>>(e);
            }
        }

    }
}