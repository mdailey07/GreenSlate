﻿using System.Configuration;

namespace Green.Challenge.Proxy.Common
{
    public class ApiConnections : ConfigurationElementCollection
    {
        public override ConfigurationElementCollectionType CollectionType =>
            ConfigurationElementCollectionType.BasicMap;

        protected override string ElementName => "connection";

        public void Add(ApiConnectionsElement serviceConfig)
        {
            BaseAdd(serviceConfig);
        }

        public void Clear()
        {
            BaseClear();
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ApiConnectionsElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ApiConnectionsElement)element).Name;
        }
    }
}
