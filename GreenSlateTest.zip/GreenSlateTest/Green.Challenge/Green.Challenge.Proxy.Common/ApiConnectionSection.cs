﻿using System.Configuration;

namespace Green.Challenge.Proxy.Common
{
    public class ApiConnectionSection : ConfigurationSection
    {
        private static ApiConnectionSection _currentConfigurationSection;

        [ConfigurationProperty("connections", IsDefaultCollection = true, IsRequired = true)]
        public ApiConnections Connections => (ApiConnections)base["connections"];

        public static ApiConnectionSection CurrentConfigurationSection =>
            _currentConfigurationSection ?? (_currentConfigurationSection =
                ConfigurationManager.GetSection("apiconnections") as ApiConnectionSection);
    }
}
