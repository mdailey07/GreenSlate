﻿using Newtonsoft.Json;

namespace Green.Challenge.Proxy.Common
{
    public static class Serializer
    {
        public static string SerializeToJson(this object message)
        {
            return JsonConvert.SerializeObject(message);
        }
        public static T DeSerializeFromJson<T>(this string json, bool withSettings = true)
        {
            return withSettings ? JsonConvert.DeserializeObject<T>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto })
                                : JsonConvert.DeserializeObject<T>(json);
        }
    }
}
