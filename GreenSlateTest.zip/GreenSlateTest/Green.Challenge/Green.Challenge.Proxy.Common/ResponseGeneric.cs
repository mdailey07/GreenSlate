﻿using System;
using System.Runtime.Serialization;

namespace Green.Challenge.Proxy.Common
{
    [DataContract]
    public class ResponseGeneric<T> : Response
    {
        [DataMember]
        public T Response { get; set; }

        public ResponseGeneric()
        {
        }

        public ResponseGeneric(T returnObject)
        {
            Response = returnObject;
            CurrentException = null;
        }

        public ResponseGeneric(Exception currentException) : base(currentException)
        {
            Response = default(T);
        }

    }
}
