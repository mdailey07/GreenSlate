﻿using System;
using System.Runtime.Serialization;

namespace Green.Challenge.Proxy.Common
{
    [DataContract]
    public class Response : IResponse
    {
        [DataMember]
        public string CurrentException { get; set; }

        [DataMember]
        public ResponseStatus Status { get; set; }

        public Response(Exception currentException)
        {
            this.CurrentException = currentException.ToString();
            this.Status = ResponseStatus.Failed;
        }

        public Response(string currentExceptionMessage)
        {
            this.CurrentException = currentExceptionMessage;
            this.Status = ResponseStatus.Failed;
        }

        public Response(string format, params object[] args)
        {
            this.CurrentException = string.Format(format, args);
            this.Status = ResponseStatus.Failed;
        }

        public Response()
        {
            this.Status = ResponseStatus.Success;
        }
    }
}
