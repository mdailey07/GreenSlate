﻿using System.Configuration;

namespace Green.Challenge.Proxy.Common
{
    public class ApiConnectionsElement : ConfigurationElement
    {
        [ConfigurationProperty("name", IsRequired = true)]
        public string Name
        {
            get { return (string)this["name"]; }
            set { this["name"] = value; }
        }

        [ConfigurationProperty("enableTrace", IsRequired = true)]
        public bool EnableTrace
        {
            get { return (bool)this["enableTrace"]; }
            set { this["enableTrace"] = value; }
        }

        [ConfigurationProperty("urlPath", IsRequired = true)]
        public string UrlPath
        {
            get { return (string)this["urlPath"]; }
            set { this["urlPath"] = value; }
        }
    }
}
