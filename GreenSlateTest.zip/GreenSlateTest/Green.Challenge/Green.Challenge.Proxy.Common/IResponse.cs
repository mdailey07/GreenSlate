﻿namespace Green.Challenge.Proxy.Common
{
    public interface IResponse
    {
        string CurrentException { get; set; }
        ResponseStatus Status { get; set; }
    }
}