﻿namespace Green.Challenge.Proxy.Common
{
    public enum ResponseStatus
    {
        Success = 0,
        Failed = 1,
        Information = 3
    }

}
