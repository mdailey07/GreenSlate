﻿using Green.Challenge.Common;
using Green.Challenge.DataAccess;
using System.Collections.Generic;
using System.Linq;

namespace Green.Challenge.Business
{
    public class DataAccessHelper : IDataAccessHelper
    {
        private readonly EFCoreDBContext _dbContext;
       

        public DataAccessHelper(EFCoreDBContext eFCoreDBContext )
        {
            _dbContext = eFCoreDBContext;
        }

        public List<User> FetchUsers()
        {
            return _dbContext.Users.ToList();
        }

        public List<Project> FetchProjects()
        {
            return _dbContext.Projects.ToList();
        }

        public List<UserProject> FetchUserProjects(IUserProject model)
        {            
            var projects = FetchProjects();
            var userprojectlist = new List<UserProject>();
            foreach (var item in _dbContext.UserProjects.Where(x=> x.UserId == model.UserId)){
                item.Project = projects.Where(x => x.Id == item.ProjectId).FirstOrDefault();
                userprojectlist.Add(item);
            }
            return userprojectlist;
        }
        
    }
}
