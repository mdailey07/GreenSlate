﻿using System.Collections.Generic;
using Green.Challenge.Common;

namespace Green.Challenge.Business
{
    public interface IDataAccessHelper
    {
        List<Project> FetchProjects();
        List<UserProject> FetchUserProjects(IUserProject model);
        List<User> FetchUsers();
    }
}