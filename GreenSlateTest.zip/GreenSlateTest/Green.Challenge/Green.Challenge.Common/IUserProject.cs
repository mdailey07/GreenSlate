﻿using System;

namespace Green.Challenge.Common
{
    public interface IUserProject
    {
        DateTime AssignedDate { get; set; }
        int Credits { get; }
        string EndDate { get; }
        int Id { get; set; }
        bool IsActive { get; set; }
        Project Project { get; set; }
        int ProjectId { get; set; }
        string StartDate { get; }
        string Status { get; }
        string TimeToStart { get; }
        User User { get; set; }
        int UserId { get; set; }
    }
}