﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Green.Challenge.Common
{
    public class UserProject : IUserProject
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public bool IsActive { get; set; }
        public DateTime AssignedDate { get; set; }
        public int ProjectId { get; set; }
        public int UserId { get; set; }

        public string Status { get { return IsActive ? "Active" : "Inative"; } }
        public string TimeToStart { get {
                var startdate = Project?.StartDate;
                if (startdate == null) startdate = DateTime.Today;
                var days = ((TimeSpan)(DateTime.Today - startdate)).Days;               
                return (days <= 0) ? "Started" : ((days == 1) ? $"{ days} day" : $"{days} days") ;
               
            } }

        public string StartDate { get { return Project?.StartDate.ToString("dd/mm/yyyy");  } }

        public string EndDate { get { return Project?.EndDate.ToString("dd/mm/yyyy"); } }
        public int Credits { get { return Project?.Credits?? 0; } }

        [ForeignKey("UserId")]
        public User User { get; set; }
        [ForeignKey("ProjectId")]
        public Project Project { get; set; }
    }
}
