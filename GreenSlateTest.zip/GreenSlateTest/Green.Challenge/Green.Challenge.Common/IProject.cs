﻿using System;

namespace Green.Challenge.Common
{
    public interface IProject
    {
        int Credits { get; set; }
        DateTime EndDate { get; set; }
        int Id { get; set; }
        DateTime StartDate { get; set; }
    }
}