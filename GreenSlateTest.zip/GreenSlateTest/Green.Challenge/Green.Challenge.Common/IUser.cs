﻿namespace Green.Challenge.Common
{
    public interface IUser
    {
        string FirstName { get; set; }
        string FullName { get;  }
        int Id { get; set; }
        string LastName { get; set; }
    }
}