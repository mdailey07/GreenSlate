﻿using Green.Challenge.Common;
using Microsoft.EntityFrameworkCore;
using System;

namespace Green.Challenge.DataAccess
{
    public class EFCoreDBContext : DbContext, IEFCoreDBContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<UserProject> UserProjects { get; set; }


        public EFCoreDBContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
                optionsBuilder.UseSqlServer("ConnectionString");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
