﻿using Green.Challenge.Common;
using Microsoft.EntityFrameworkCore;

namespace Green.Challenge.DataAccess
{
    public interface IEFCoreDBContext
    {
        DbSet<Project> Projects { get; set; }
        DbSet<UserProject> UserProjects { get; set; }
        DbSet<User> Users { get; set; }
    }
}