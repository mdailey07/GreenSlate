﻿using NetSuiteConnectionTest.com.netsuite.webservices;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography;

namespace NetSuiteConnectionTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string account = "4702124_SB1";
            string consumerKey = "43b798431a42a4815c61d610ed8d3fff1b1ee660782f993faa11fa920d43866a";
            string consumerSecret = "9e3100ff2d6f9aec0ce88c5d7532af9fb0e4de7d26a829b0f8789218914fc971";
            string tokenId = "e2c77725bbb2167b9453a0ec13c90cc5edebff52d60b9d45903ce1d66b39abca";
            string tokenSecret = "5a62b4055eae799b8f722c8b9903e7206b529d45a6570467615c53bdf571cedc";

            AddInvoice(account, consumerKey, consumerSecret, tokenId, tokenSecret);
        }

        private static void FirtsCall(string account, string consumerKey, string consumerSecret, string tokenId, string tokenSecret)
        {
            DataCenterAwareNetSuiteService _service = GetServicesConfiguration(account);

            var result = GetCurrency(_service, account, consumerKey, consumerSecret, tokenId, tokenSecret);

            Record[] records = result.recordList;
        }

        private static void AddInvoice(string account, string consumerKey, string consumerSecret, string tokenId, string tokenSecret)
        {
            DataCenterAwareNetSuiteService _service = GetServicesConfiguration(account);

            TokenPassport tokenPassport = GtTokenPassport(account, consumerKey, consumerSecret, tokenId, tokenSecret);

            _service.tokenPassport = tokenPassport;

            Invoice invoice = new Invoice
            {
                exchangeRate = 1,
                tranDate = DateTime.UtcNow,
                memo = "marlon test from WS"
            };

            RecordRef entityCustomerRef = new RecordRef
            {
                type = RecordType.customer,
                typeSpecified = true,
                internalId = "1949", // ???
                externalId=  "" // ?? ? quien los definio ? 
            };

            RecordRef deparmentRef = new RecordRef
            {
                type = RecordType.department,
                typeSpecified = true,
                internalId = "2", // ???
                externalId = "" // ?? ? quien los definio ? 
            };

            RecordRef subsidiaryRef = new RecordRef
            {
                type = RecordType.subsidiary,
                typeSpecified = true,
                internalId = "3", // ???
                externalId = "" // ?? ? quien los definio ? 
            };

            //RecordRef postingPeriodRef = new RecordRef
            //{
            //    type = RecordType.periodEndJournal,
            //    typeSpecified = true,
            //    internalId = "1949", // ???
            //    externalId = "" // ?? ? quien los definio ? 
            //};

            //invoice.postingPeriod = postingPeriodRef
            invoice.subsidiary = subsidiaryRef;
            invoice.department = deparmentRef;
            invoice.entity = entityCustomerRef;
            invoice.amountPaid = 1000;
            invoice.externalId = "123452";


            var itemList = new List<InvoiceItem>
            {
                new InvoiceItem()
                {
                    amount = 1000,
                    amountSpecified = true,
                    quantity = 10,
                    description = "marlon test item 1",
                    item = new RecordRef()
                    {
                        internalId = "18"
                    }
                }
            };

            var invoiceItemList = new InvoiceItemList()
            { 
                item = itemList.ToArray()
            };

            invoice.itemList = invoiceItemList;

            WriteResponse result = _service.add(invoice);
            if (result != null && !(result?.status?.isSuccess ?? false))
            {
                var status = result.status;
                var data = status.statusDetail;
            }
        }

        private static DataCenterAwareNetSuiteService GetServicesConfiguration(string account)
        {
            var Prefs = new Preferences
            {
                warningAsErrorSpecified = true,
                warningAsError = false,
                ignoreReadOnlyFieldsSpecified = true,
                ignoreReadOnlyFields = true
            };

            var SearchPreferences = new SearchPreferences
            {
                pageSize = 5,
                pageSizeSpecified = true,
                bodyFieldsOnly = true
            };

            var _service = new DataCenterAwareNetSuiteService(account, false)
            {
                Timeout = 1000 * 60 * 60 * 2,
                preferences = Prefs,
                searchPreferences = SearchPreferences
            };

            return _service;
        }

        private static GetAllResult GetCurrency(DataCenterAwareNetSuiteService _service, string account, string  consumerKey, string consumerSecret, string tokenId, string tokenSecret)
        {
            TokenPassport tokenPassport = GtTokenPassport(account, consumerKey, consumerSecret, tokenId, tokenSecret);

            _service.tokenPassport = tokenPassport;

            GetAllRecord record = new GetAllRecord
            {
                recordTypeSpecified = true,
                recordType = GetAllRecordType.currency
            };

            GetAllResult result = _service.getAll(record);

            return result;
        }

        private static TokenPassport GtTokenPassport(string account, string consumerKey, string consumerSecret, string tokenId, string tokenSecret)
        {
            string nonce = GetNonce();
            long timestamp = GetTimestamp();

            TokenPassportSignature signature = ComputeSignature(account, consumerKey, consumerSecret, tokenId, tokenSecret, nonce, timestamp);
            
            TokenPassport tokenPassport = new TokenPassport
            {
                account = account,
                consumerKey = consumerKey,
                token = tokenId,
                nonce = nonce,
                timestamp = timestamp,
                signature = signature
            };
            
            return tokenPassport;
        }

        private static long GetTimestamp()
        {
            return ((long)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds);
        }

        private static string GetNonce()
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            byte[] data = new byte[20];
            rng.GetBytes(data);
            int value = Math.Abs(BitConverter.ToInt32(data, 0));
            string nonce = value.ToString();
            return nonce;
        }

        private static TokenPassportSignature ComputeSignature(string accountId, string consumerKey, string consumerSecret,
            string tokenId, string tokenSecret, string nonce, long timestamp)
        {
            string baseString = $"{accountId}&{consumerKey}&{tokenId}&{nonce}&{timestamp}";
            string key = $"{consumerSecret}&{tokenSecret}";
            string signature = "";

            var encoding = new System.Text.ASCIIEncoding();
            byte[] keyBytes = encoding.GetBytes(key);
            byte[] baseStringBytes = encoding.GetBytes(baseString);

            using (var hmacSha1 = new HMACSHA256(keyBytes))
            {
                byte[] hashBaseString = hmacSha1.ComputeHash(baseStringBytes);
                signature = Convert.ToBase64String(hashBaseString);
            }
            TokenPassportSignature sign = new TokenPassportSignature
            {
                algorithm = "HMAC-SHA256",
                Value = signature
            };
            return sign;
        }

    }

    class DataCenterAwareNetSuiteService : NetSuiteService
    {

        private System.Uri OriginalUri;

        public DataCenterAwareNetSuiteService(string account, bool doNotSetUrl)
            : base()
        {
            OriginalUri = new System.Uri(this.Url);
            if (account == null || account.Length == 0)
                account = "empty";
            if (!doNotSetUrl)
            {
                DataCenterUrls urls = getDataCenterUrls(account).dataCenterUrls;
                Uri dataCenterUri = new Uri(urls.webservicesDomain + OriginalUri.PathAndQuery);
                this.Url = dataCenterUri.ToString();
            }
        }

        public void SetAccount(string account)
        {
            if (account == null || account.Length == 0)
                account = "empty";

            this.Url = OriginalUri.AbsoluteUri;
            DataCenterUrls urls = getDataCenterUrls(account).dataCenterUrls;
            Uri dataCenterUri = new Uri(urls.webservicesDomain + OriginalUri.PathAndQuery);
            this.Url = dataCenterUri.ToString();
        }
    }

    class OverrideCertificatePolicy : ICertificatePolicy
    {
        public bool CheckValidationResult(ServicePoint srvPoint, System.Security.Cryptography.X509Certificates.X509Certificate certificate, WebRequest request, int certificateProblem)
        {
            return true;
        }
    }
}
